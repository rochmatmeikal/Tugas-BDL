### TRANS PROPERTY ###

#LANGKAH Instalasi/Menjalankan Program Trans Property:

1. Pindahkan Folder ke C:xampp/htdocs/ (lalu extrac!!)

2. Nyalakan Xampp Terlebih Dahulu!!! (mengklik "START" Pada Apache dan MySQL)

3. Buka (http://localhost/phpmyadmin/) pada browser Anda!!!

4. Buat Database baru pada PhpMyAdmin dengan Nama "real_estate" lalu klik "import" yang ada pada navbar.
   Pilih file "real_estate.sql" yang ada pada C:xampp/htdocs/TransProperty/database/. jika sudah langung klik kirim

5. Jika Sudah Berhasil mengimport databasenya, langsung saja kita masuk lagi ke browser lalu ketikan (http://localhost/TransProperty/)

6. Selamat.. Perogram Penjualan Property Trans Property telah dapat di jalankan... :)

7. Nah, Jika ingin masuk ke halaman ADMIN maka tinggal ketikan saja di browser (https://localhost/TransProperty/admin/)
   Login Menggunakan : Email :admin@gmail.com
		       Password : admin


#FITUR :
1. LOGIN AGENT
2. REGISTER AGENT
3. Tambahkan Properti (Agent)
4. Tambahkan Gambar Properti (Agent)
5. LOGIN ADMIN (https://localhost/TransProperty/admin/) email : admin@gmail.com | password : admin
6. Edit Property (Admin)
7. Edit Gambar (Admin)
8. Delete Property (Admin)
9. Delete Gambar (Admin)
10. Edit Agent (Admin)
11. Delete Agent (Admin)
12. Tambahkan Report (Admin)
13. Cetak Report (Admin)

1. Apa Saja Yang bisa dilakukan custemer yang ingin memmbeli rumah?
# Pembeli bisa langsung pergi ke halaman properties dan memilih peroperti yang diinginkan. 
jika pembeli tertarik, maka pembeli bisa klik tombol "BELI" yang akan langsung terhubung ke 
whatsapp agent yang memasang iklan.

2. Apa Saja Yang bisa dilakukan custemer yang ingin menjual rumah?
#Penjual bisa langsung pergi ke halaman agent dan memilih agent yang terbaik. 
jika penjual sudah mendapatkan agent yang terbaik, maka penjual bisa klik tombol 
"Hubungi Agent" yang akan langsung terhubung ke whatsapp agent tersebut.

3. Apa Saja Yang bisa dilakukan Agent?
#Agent bisa langsung pergi ke halaman Agent lalu login dengan email dan password yang telah dimiliki.
Jika customer ingin mendaftar menjadi Agent, tingggal klik Register.. Lalu login.

Setelah Agent Login.. Maka Agent Bisa melakukan fitur 3 dan 4. Selain itu Agent bisa menghubungi Admin Jika Ada Permasalahan.

4. Apa Saja Yang bisa dilakukan Admin?
#Admin dapat melakukan fitur 5 - 13 yang ada di halaman Admin


----SELAMAT MENCOBA-----
Developer : Rochmat Meikal

Copy Right 2021 | Trans Property
