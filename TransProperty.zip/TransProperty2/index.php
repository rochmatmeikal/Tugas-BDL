
<?php include('include/header.php');?>
<!-- main header end -->

<!-- Banner start -->
<div class="banner banner-bg" id="particles-banner-wrapper">
    <div id="particles-banner"></div>
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item item-bg active">
                <div class="carousel-caption banner-slider-inner d-flex h-100 text-left">
                    <div class="carousel-content container">
                        <div class="t-center">
                            <h2 data-animation="animated fadeInDown delay-05s">Ingin Menjual Rumah Dengan Mudah, Cepat Dan Aman ?</h2>
                            <p class="text-p" data-animation="animated fadeInUp delay-10s">
                                Tenang kami punya solusinya, Trans Property kini hadir membantu anda dalam menjual property.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item item-bg">
                <div class="carousel-caption banner-slider-inner d-flex h-100 text-left">
                    <div class="carousel-content container">
                        <div class="t-right">
                            <h2 data-animation="animated fadeInDown delay-05s">Temukan Properti Impian Anda</h2>
                            <p class="text-p" data-animation="animated fadeInUp delay-10s">
                                Hanya di Trans Property anda bisa menggapai impian anda .
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="carousel-item item-bg">
                <div class="carousel-caption banner-slider-inner d-flex h-100 text-left">
                    <div class="carousel-content container">
                        <div class="t-left">
                            <h2 data-animation="animated fadeInUp delay-05s">Ada Ingin Menjadi Agen?</h2>
                            <p class="text-p" data-animation="animated fadeInUp delay-10s">
                                Bergabung Sekarang dan Dapatkan Keuntungannya!
                            </p>
                            <a data-animation="animated fadeInUp delay-10s" href="agen/index.php" class="btn btn-lg btn-round btn-white-lg-outline">Login</a>
                            <a data-animation="animated fadeInUp delay-10s" href="agen/register.php" class="btn btn-lg btn-round btn-white-lg-outline">Register</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- banner end -->


<!-- Featured properties start -->
<div class="featured-properties content-area-19">
    <div class="container">
        <div class="main-title">
            <h1>Properti Unggulan</h1>
            <p>Kami Menyediakan Properti Terbaik Untuk Anda</p>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInLeft delay-04s">
                <div class="card property-box-2">
                    <!-- property img -->
                    <div class="property-thumbnail">
                        <a href="properties-details.html" class="property-img">
                            <img src="assets/img/property-3.jpg" alt="property-3" class="img-fluid">
                        </a>
                        <div class="property-overlay">
                            <a href="properties-details.html" class="overlay-link">
                                <i class="fa fa-link"></i>
                            </a>
                            <a class="overlay-link property-video" title="Test Title">
                                <i class="fa fa-video-camera"></i>
                            </a>
                            <div class="property-magnify-gallery">
                                <a href="assets/img/property-3.jpg" class="overlay-link">
                                    <i class="fa fa-expand"></i>
                                </a>
                                <a href="assets/img/property-7.jpg" class="hidden"></a>
                                <a href="assets/img/property-6.jpg" class="hidden"></a>
                            </div>
                        </div>
                    </div>
                    <!-- detail -->
                    <div class="detail">
                        <h5 class="title"><a href="properties-details.html">Rumah Keluarga</a></h5>
                        <h4 class="price">
                            Rp.860.000.000
                        </h4>
                        <p>Rumah yang sangat nyaman dan aman untuk keluarga kecil.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp delay-04s">
                <div class="card property-box-2">
                    <!-- property img -->
                    <div class="property-thumbnail">
                        <a href="properties-details.html" class="property-img">
                            <img src="assets/img/property-7.jpg" alt="property-7" class="img-fluid">
                        </a>
                        <div class="property-overlay">
                            <a href="properties-details.html" class="overlay-link">
                                <i class="fa fa-link"></i>
                            </a>
                            <a class="overlay-link property-video" title="Test Title">
                                <i class="fa fa-video-camera"></i>
                            </a>
                            <div class="property-magnify-gallery">
                                <a href="assets/img/property-7.jpg" class="overlay-link">
                                    <i class="fa fa-expand"></i>
                                </a>
                                <a href="assets/img/property-4.jpg" class="hidden"></a>
                                <a href="assets/img/property-3.jpg" class="hidden"></a>
                            </div>
                        </div>
                    </div>
                    <!-- detail -->
                    <div class="detail">
                        <h5 class="title"><a href="properties-details.html">Rumah Apartment</a></h5>
                        <h4 class="price">
                            Rp.370.000.000
                        </h4>
                        <p>Rumah yang sangat cocok untuk anda yang single dan bekerja di kota, lokasi property ini sangat strategis.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp delay-04s">
                <div class="card property-box-2">
                    <!-- property img -->
                    <div class="property-thumbnail">
                        <a href="properties-details.html" class="property-img">
                            <img src="assets/img/property-5.jpg" alt="property-5" class="img-fluid">
                        </a>
                        <div class="property-overlay">
                            <a href="properties-details.html" class="overlay-link">
                                <i class="fa fa-link"></i>
                            </a>
                            <a class="overlay-link property-video" title="Test Title">
                                <i class="fa fa-video-camera"></i>
                            </a>
                            <div class="property-magnify-gallery">
                                <a href="assets/img/property-5.jpg" class="overlay-link">
                                    <i class="fa fa-expand"></i>
                                </a>
                                <a href="assets/img/property-7.jpg" class="hidden"></a>
                                <a href="assets/img/property-6.jpg" class="hidden"></a>
                            </div>
                        </div>
                    </div>
                    <!-- detail -->
                    <div class="detail">
                        <h5 class="title"><a href="properties-details.html">Rumah Elite</a></h5>
                        <h4 class="price">
                            Rp.1.870.000.000
                        </h4>
                        <p>Rumah Elite dengan fasilitas lengkap, posisi berada di tengah kota. sangat dekat dengan mall, bank, airport, stasiun kereta dan rumah sakit.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInRight delay-04s">
                <div class="card property-box-2">
                    <!-- property img -->
                    <div class="property-thumbnail">
                        <a href="properties-details.html" class="property-img">
                            <img src="assets/img/property-1.jpg" alt="property-1" class="img-fluid">
                        </a>
                        <div class="property-overlay">
                            <a href="properties-details.html" class="overlay-link">
                                <i class="fa fa-link"></i>
                            </a>
                            <a class="overlay-link property-video" title="Test Title">
                                <i class="fa fa-video-camera"></i>
                            </a>
                            <div class="property-magnify-gallery">
                                <a href="assets/img/property-1.jpg" class="overlay-link">
                                    <i class="fa fa-expand"></i>
                                </a>
                                <a href="assets/img/property-7.jpg" class="hidden"></a>
                                <a href="assets/img/property-3.jpg" class="hidden"></a>
                            </div>
                        </div>
                    </div>
                    <!-- detail -->
                    <div class="detail">
                        <h5 class="title"><a href="properties-details.html">Rumah Mewah</a></h5>
                        <h4 class="price">
                            Rp.8.500.000.000
                        </h4>
                        <p>Rumah Mewah dengan fasilitas super mewah dan keamanan yang sangat baik, Semua Tersedia disini.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Featured properties end -->


<!-- Recent Properties start -->
<div class="recent-properties content-area-2">
    <div class="container">
        <div class="main-title">
            <h1>Properti Terbaru</h1>
            <p>Semua Properti Terbaru ada disini, kami sudah pastikan peroperti kami sangat berkualitas karena dipilih oleh agen yang berkualitas.</p>
        </div>
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInLeft delay-04s">
                <div class="property-box-8">
                    <div class="property-photo">
                        <img src="assets/img/property-3.jpg" alt="property-6" class="img-fluid">
                        <div class="date-box">For Sale</div>
                    </div>
                    <div class="detail">
                        <div class="heading">
                            <h3>
                                <a href="properties-details.html">Rumah Mewah Sekali</a>
                            </h3>
                            <div class="location">
                                <a href="properties-details.html">
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>Jalan Tukad Badung, No.12 Denpasar
                                </a>
                            </div>
                        </div>
                        <div class="properties-listing">
                            <span>5 Kamar Tidur</span>
                            <span>3 Kamar Mandi</span>
                            <span>980 m<sup>2</sup></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp delay-04s">
                <div class="property-box-8">
                    <div class="property-photo">
                        <img src="assets/img/property-6.jpg" alt="property-6" class="img-fluid">
                        <div class="date-box">For Sale</div>
                    </div>
                    <div class="detail">
                        <div class="heading">
                            <h3>
                                <a href="properties-details.html">Rumah Komplek</a>
                            </h3>
                            <div class="location">
                                <a href="properties-details.html">
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>Jalan Gunung Rinjani, No.10 Denpasar
                                </a>
                            </div>
                        </div>
                        <div class="properties-listing">
                            <span>3 Kamar Tidur </span>
                            <span>2 Kamar Mandi</span>
                            <span>500 m<sup>2</sup></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInUp delay-04s">
                <div class="property-box-8">
                    <div class="property-photo">
                        <img src="assets/img/property-2.jpg" alt="property-2" class="img-fluid">
                        <div class="date-box">For Sale</div>
                    </div>
                    <div class="detail">
                        <div class="heading">
                            <h3>
                                <a href="properties-details.html">Rumah BTN</a>
                            </h3>
                            <div class="location">
                                <a href="properties-details.html">
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>Jalan Raya Kediri No.20 Tabanan
                                </a>
                            </div>
                        </div>
                        <div class="properties-listing">
                            <span>5 Kamar Tidur</span>
                            <span>2 Kamar Mandi</span>
                            <span>800 m<sup>2</sup></span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 wow fadeInRight delay-04s">
                <div class="property-box-8">
                    <div class="property-photo">
                        <img src="assets/img/property-1.jpg" alt="property-6" class="img-fluid">
                        <div class="date-box">For Sale</div>
                    </div>
                    <div class="detail">
                        <div class="heading">
                            <h3>
                                <a href="properties-details.html">Rumah Elite</a>
                            </h3>
                            <div class="location">
                                <a href="properties-details.html">
                                    <i class="flaticon-facebook-placeholder-for-locate-places-on-maps"></i>Jl. Tegal Badeng Timur, No.10 Jembrana
                                </a>
                            </div>
                        </div>
                        <div class="properties-listing">
                            <span>3 Kamar Tidur</span>
                            <span>2 Kamar Mandi</span>
                            <span>980 m<sup>2</sup></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Recent Properties end -->


<!-- Testimonial 2 start -->
<div class="testimonial-2 overview-bgi" style="background-image: url(assets/img/testimonial-property.jpg)">
    <div class="container">
        <div class="row">
            <div class="offset-lg-2 col-lg-8">
                <div class="testimonial-inner">
                    <header class="testimonia-header">
                        <h1>Testimoni</h1>
                    </header>
                    <div id="carouselExampleIndicators7" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div class="row">
                                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <div class="avatar">
                                            <img src="assets/img/avatar/avatar-2.jpg" alt="avatar-2" class="img-fluid rounded">
                                        </div>
                                    </div>
                                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                        <p class="lead">
                                            Berkat Trans Property Saya bisa mendapatkan rumah impian saya, semua urusan pembelian berjalan dengan lancar dan mudah.
                                        </p>
                                        <div class="author-name">
                                            Bulan Sutena
                                        </div>
                                        <ul class="rating">
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <div class="avatar">
                                            <img src="assets/img/avatar/avatar.jpg" alt="avatar" class="img-fluid rounded">
                                        </div>
                                    </div>
                                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                        <p class="lead">
                                            Saya sangat terbantu sekali dengan adanya transproperty, mencari rumah yang saya inginkan sangat mudah dan gampang disini. semua urusan telah d handle oleh agentnya
                                        </p>
                                        <div class="author-name">
                                            Theodorus Ginting
                                        </div>
                                        <ul class="rating">
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="carousel-item">
                                <div class="row">
                                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-xs-12">
                                        <div class="avatar">
                                            <img src="assets/img/avatar/avatar-3.jpg" alt="avatar-3" class="img-fluid rounded">
                                        </div>
                                    </div>
                                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-xs-12">
                                        <p class="lead">
                                            Rumah saya cepat laku terjual dengan harga yang saya inginkan disini. Agentnya sangat bertanggung jawab dengan tugasnya.
                                        </p>
                                        <div class="author-name">
                                            Coki Pardede
                                        </div>
                                        <ul class="rating">
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                            <li>
                                                <i class="fa fa-star"></i>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <a class="carousel-control-prev" href="#carouselExampleIndicators7" role="button" data-slide="prev">
                            <span class="slider-mover-left" aria-hidden="true">
                                <i class="fa fa-angle-left"></i>
                            </span>
                        </a>
                        <a class="carousel-control-next" href="#carouselExampleIndicators7" role="button" data-slide="next">
                            <span class="slider-mover-right" aria-hidden="true">
                                <i class="fa fa-angle-right"></i>
                            </span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div><br/><br/><br/><br/>
<!-- Testimonial 2 end -->



<!-- partner start -->
<div class="container partner">
    <div class="main-title">
        <h1>Partners</h1>
    </div>
    <div class="row">
        <div class="multi-carousel" data-items="1,3,5,6" data-slide="1" id="multiCarousel"  data-interval="1000">
            <div class="multi-carousel-inner">
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Audiojungle</p>
                        <img src="assets/img/brands/brand-1.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Codecanyon</p>
                        <img src="assets/img/brands/brand-2.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Graphicriver</p>
                        <img src="assets/img/brands/brand-3.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Themeforest</p>
                        <img src="assets/img/brands/brand-4.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Tuts</p>
                        <img src="assets/img/brands/brand-5.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Audiojungle</p>
                        <img src="assets/img/brands/brand-1.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Codecanyon</p>
                        <img src="assets/img/brands/brand-2.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Graphicriver</p>
                        <img src="assets/img/brands/brand-3.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Themeforest</p>
                        <img src="assets/img/brands/brand-4.png" alt="brand">
                    </div>
                </div>
                <div class="item">
                    <div class="pad15">
                        <p class="lead">Tuts</p>
                        <img src="assets/img/brands/brand-5.png" alt="brand">
                    </div>
                </div>
            </div>
            <a class="multi-carousel-indicator leftLst" aria-hidden="true">
                <i class="fa fa-angle-left"></i>
            </a>
            <a class="multi-carousel-indicator rightLst" aria-hidden="true">
                <i class="fa fa-angle-right"></i>
            </a>
        </div>
    </div>
</div>
<!-- partner end -->

<!-- Footer start -->
<?php include('include/footer.php');?>