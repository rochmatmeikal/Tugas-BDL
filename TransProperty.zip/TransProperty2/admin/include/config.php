<?php
$con=mysqli_connect('localhost','root','','real_estate')or die(mysqli_error());

?>